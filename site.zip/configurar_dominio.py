from pathlib import Path
import sys
root=Path(__file__).resolve().parent
old='https://calculonitido.com'
new=(sys.argv[1] if len(sys.argv)>1 else input('Dominio completo (ej. https://misitio.com): ')).rstrip('/')
if not new.startswith('http'): raise SystemExit('Usa https://...')
old_email='hola@calculonitido.com'
new_email='hola@'+new.split('://',1)[1].replace('www.','').split('/')[0]
for p in root.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.html','.xml','.txt','.js','.toml','.md'}:
        try: s=p.read_text(encoding='utf-8')
        except: continue
        s=s.replace(old,new).replace(old_email,new_email)
        p.write_text(s,encoding='utf-8')
print('Dominio actualizado a',new)
print('Correo actualizado a',new_email)
