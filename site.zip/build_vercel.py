from pathlib import Path
import os, shutil, re

ROOT = Path(__file__).resolve().parent
DIST = ROOT / 'dist'
# VERCEL_PROJECT_PRODUCTION_URL is host without scheme, e.g. calculo-nitido.vercel.app
host = os.environ.get('VERCEL_PROJECT_PRODUCTION_URL') or os.environ.get('VERCEL_URL') or 'calculo-nitido.vercel.app'
SITE_URL = host if host.startswith('http') else 'https://' + host
SITE_URL = SITE_URL.rstrip('/')
ADSENSE_CLIENT = os.environ.get('ADSENSE_CLIENT','').strip()
GOOGLE_VERIFY = os.environ.get('GOOGLE_SITE_VERIFICATION','').strip()

if DIST.exists(): shutil.rmtree(DIST)
DIST.mkdir()
skip_names={'dist','.git','__pycache__'}
skip_suffixes={'.md','.py','.zip'}
for src in ROOT.rglob('*'):
    rel=src.relative_to(ROOT)
    if any(part in skip_names for part in rel.parts) or src.is_dir(): continue
    if src.suffix.lower() in skip_suffixes: continue
    dst=DIST/rel; dst.parent.mkdir(parents=True,exist_ok=True)
    if src.suffix.lower() in {'.html','.xml','.txt','.webmanifest','.js','.css'} or src.name in {'robots.txt','ads.txt','_redirects'}:
        try: text=src.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            shutil.copy2(src,dst); continue
        text=text.replace('https://calculo-nitido.vercel.app', SITE_URL)
        text=text.replace('https://calculonitido.com', SITE_URL)
        if src.suffix.lower()=='.html':
            marker='<!-- ADSENSE: pega aquí el código de verificación/Auto ads cuando Google te entregue tu ca-pub-XXXXXXXXXXXX -->'
            inject=[]
            if GOOGLE_VERIFY:
                inject.append(f'<meta name="google-site-verification" content="{GOOGLE_VERIFY}">')
            if ADSENSE_CLIENT and re.fullmatch(r'ca-pub-\d+', ADSENSE_CLIENT):
                inject.append(f'<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ADSENSE_CLIENT}" crossorigin="anonymous"></script>')
            text=text.replace(marker,'\n'.join(inject) if inject else marker)
        if src.name=='ads.txt' and ADSENSE_CLIENT and re.fullmatch(r'ca-pub-\d+',ADSENSE_CLIENT):
            pub=ADSENSE_CLIENT.removeprefix('ca-')
            text=f'google.com, {pub}, DIRECT, f08c47fec0942fa0\n'
        dst.write_text(text,encoding='utf-8')
    else:
        shutil.copy2(src,dst)
print(f'Built {DIST} for {SITE_URL}')
